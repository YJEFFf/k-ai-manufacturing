# 북적북적 코드 제출본

결과보고서의 공식 모델(기반 모델 v2 + 규칙 R1·R2, 두 단계 경보), 2.8절 사후 보완 실험, 추가 감사를 이 폴더에서 다시 만듭니다. 원본 CSV 2개와 필요한 팀 모듈이 모두 들어 있어 저장소를 따로 받을 필요가 없습니다.

한글 폴더 이름이 깨져 보이면 `python -m zipfile -e 북적북적_code_통합본.zip .`로 압축을 푸세요.

## 1. 설치 없이 확인(수 초)

```console
python check_bundled.py
```

표준 라이브러리만 씁니다. 배포 파일 해시와 동봉한 공식 test 예측 파일 해시를 확인하고, 그 파일의 `label`과 경보 열로 행 F1을 다시 계산합니다. 행 F1(분할 A·B)은 1단계 v2+R1(공식 성능) 1.000·0.995, 2단계 v2+R1+R2 1.000·1.000, 기반 모델 v2 0.965·0.970입니다.

## 2. 설치와 실행

```console
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python run_all.py
```

- 파이썬 3.13 또는 3.14가 필요합니다. 검증한 환경은 Windows 11·파이썬 3.13.15와 Windows 10·파이썬 3.14.7입니다. macOS·Linux는 `.venv/bin/python`을 쓰며 실행해 보지는 않았습니다. Linux에서는 `pip install torch==2.14.0 --index-url https://download.pytorch.org/whl/cpu`를 먼저 하면 CUDA 라이브러리를 받지 않습니다.
- 패키지 설치에만 인터넷이 필요하고, 압축을 푼 경로에 공백이나 한글이 있어도 됩니다. 하나라도 어긋나면 종료 코드가 0이 아닙니다.
- 전체 실행은 검증 PC에서 약 70분(공식 파이프라인 26단계 약 52분) 걸립니다. 화면에는 단계 시작과 통과만 나오고 진행 내용은 `logs/integrated_<단계>.log`에 쌓이므로, 공식 단계에서 한 시간 가까이 화면이 멈춰 보여도 정상입니다.

| 명령 | 내용 |
|---|---|
| `run_all.py` | 전체: 공식 파이프라인 26단계(보고서 수치 43항목 대조), 2.8절 실험, 추가 감사, 계약 검사(pytest) |
| `run_all.py --section official` | 공식 파이프라인 26단계만 |
| `run_all.py --section official --quick` | 공식 파이프라인 핵심 13단계(대조 28항목) |
| `run_all.py --section improvement` | 2.8절 실험과 그 추가 감사 |
| `run_all.py --skip-extra-audits` | 추가 감사 제외 |
| `run_all.py --verify-only` | 이 폴더에서 이미 실행한 결과만 다시 검사 |

추가 감사 결과는 `reference_results/extra_audits/`의 기준표 32개와 자동으로 대조합니다. 단계 로그는 `logs/`, 실행 요약은 `logs/integrated_run_summary.json`에 남습니다.

## 3. 코드 구조

공식 결과는 표의 앞 세 줄을 따라가면 됩니다. 나머지는 그 결과를 검증하거나 보고서 1·3·4장의 근거를 만드는 코드입니다.

| 위치 | 하는 일 | 보고서 |
|---|---|---|
| `code/press/tvt/01`·`02`·`03`·`05`·`08` | 공식 파이프라인: 정상 train 학습과 valid 보정, valid 선택과 해시 잠금, 잠금 확인 뒤 test 채점, test 예측 파일, 이상 확률 열(경보와 무관) | 2.3~2.5절 |
| `yejun/press_guard/model.py`, `yejun/press_submission/press/`, `yejun/analysis/press_master_validation_2026-10-03/core.py` | 기반 모델 v2(크기·파형·동역학 성분, conformal 문턱), v1 성분·베이스라인·LSTM, v3 모듈과 인공 고장 주입 생성기 | 2.3·2.4·2.6절 |
| `code/press/tvt/lib.py`, `evalcore.py` | 규칙 R1(`lib.stream_rules`)·R2(`evalcore.own_alarm`, `lib.prefix_r2`)와 행 단위 채점 | 2.5절 |
| `code/press/cases/`, `code/press/06_alias_frequency_audit.py` | 데이터 진단: 기록 특징, 저장 형식 누수, 겉보기 주파수 | 1장 |
| `code/press/tvt/04`, `06`·`07`, `09`~`16` | 검증과 사후 대조: 인공 고장 주입, 성분 절제, 문턱 무관 비교, R2 표본 밖 확인 등 | 2.6·2.7절 |
| `code/press/domain/` | 영향요인과 오경보 조건: 신호 물리, PCA 관리도, CUSUM·EWMA, 운전 상태 | 3장 |
| `yejun/analysis/press_improvement/` | 2.8절 보완 실험: 정상 전용 선택, 잠금, 평가, 모델 동결, 새 자료 평가 도구 | 2.8절 |
| `yejun/analysis/press_official_sensitivity/`, `press_stage_replay/` | 규칙 상수 민감도, 두 단계 경보 재생과 정상 자료 경보량 | 2.7·4.3절 |
| `yejun/press_guard/stages.py`, `stage_console.py` | 두 단계 경보 스트림(`run_all.py`가 재생 대조)과 점검 콘솔(`run_all.py` 범위 밖, 모델 파일 `yejun/press_guard/artifacts/guard_*.json`이 있어야 열림) | 4.2절 |
| `yejun/analysis/press_lstm_improvement/` | 2.7절 보완 LSTM 비교(사후). `run_all.py` 범위 밖이며 결과 표를 동봉했다. 다시 돌리면 학습 162회, 약 8시간 | 2.7절 |
| `expected_results.json`, `reference_results/` | 보고서 수치 기대값, 동봉 예측 파일과 추가 감사 기준표 | 6장 |

실행 결과는 `predictions/`(공식 test 예측 파일), `code/press/*/outputs/`, `yejun/analysis/*/outputs/`에 생깁니다. 보고서의 R1·R2는 코드에서 H1·H2로, 검증 E1·E2·E3·E5는 V1·V2·V3·V5로 부릅니다.

## 4. 검증 기록과 범위

- `verification/clean_full_run.json`은 새 가상환경과 새로 푼 폴더에서 `python run_all.py`를 끝까지 돌린 기록(단계별 시간과 결과)입니다. 실행한 빌드의 SHA-256은 `package_manifest.json`의 `verification_basis`에 있습니다. 그 뒤로는 README·주석·docstring만 고쳤고, 계산 코드와 기대값 숫자가 같다는 대조 결과는 `verification/doc_only_changes.json`에 있습니다.
- `run_official.py`는 시작할 때 "결과는 파이썬 3.13에서 만들었다"고 출력합니다. 기존 결과를 처음 만든 환경을 알리는 문장입니다.
- `README_original.md`는 통합 전 제출본 설명서입니다. 그 문서의 `run_all.py`는 이 폴더의 `run_official.py`, `predictions/`는 `reference_results/official_predictions/`, `environment.yml`은 `environment_original.yml`에 해당하며, 예측 파일 열 설명(3절)은 그대로 유효합니다.
- `yejun/` 아래 README·PLAN·PROTOCOL과 `yejun/press_submission/run_all.py`·`yejun/press_guard/reproduce.py`는 각 모듈을 만들 때의 팀 저장소 기록입니다. 그 안의 실행 방법(파이썬 3.11~3.12 등)과 이 폴더에 없는 파일(시험 코드·그림·캐시·계획 문서)은 쓰지 않고, 실행은 이 README를 따릅니다. 문서와 주석의 `claude/code/press/`는 이 폴더의 `code/press/`이고, '예준'·'준용'은 팀원 이름, '사이클·평가관 NN' 같은 번호는 팀 내부 검토 회차입니다. 공식 계산이 불러 쓰는 모듈은 해시로 잠가 두어 이런 문구도 고치지 않았습니다.
- 추가 감사는 공식 모델·문턱·규칙을 바꾸지 않습니다. 같은 고장 자료를 다시 계산하는 검증이라 새 설비·새 고장 사건에 대한 일반화 검증과는 다릅니다. 이상 21기록은 21개의 독립 고장이 아닙니다.
- 2.8절 실험의 분할·주입·선택 기준은 `yejun/analysis/press_improvement/PROTOCOL.md`에 있습니다. 후보 56개와 비교용 OR 4개의 계산은 실험 당시 코드와 구문(AST) 단위로 같고, 실제 실행은 정상 전용 선택부터 새로 해서 `outputs/selection_lock.json`을 만듭니다.

## 5. 새로 수집한 자료 평가

전체 또는 2.8절 실행 뒤 `yejun/analysis/press_improvement/outputs/frozen_holdout/provenance.example.json`을 복사해 수집 출처·설비·사건 정보를 적습니다. 같은 공정, 같은 센서·단위, 10 Hz 표본 간격이어야 하며 새 자료로 재학습·재보정·후보 선택을 하지 않습니다.

```console
python yejun/analysis/press_improvement/validate_holdout.py evaluate --artifact yejun/analysis/press_improvement/outputs/frozen_holdout --split A --csv new_session.csv --provenance provenance.json --output new_validation
```

정답 0/1 열이 있으면 `--label-column 열이름`, 기록 경계 열이 있으면 `--record-column 열이름`을 붙입니다. 정답이 없으면 경보 건수만 내고 탐지율·오경보율이라고 부르지 않습니다. 기존 파일을 자르거나 이름·시각만 바꾼 사본은 중복 검사에서 거부합니다.
