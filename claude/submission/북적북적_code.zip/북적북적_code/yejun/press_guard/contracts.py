"""v2의 필수 코드·단계·산출물 계약. 선택적으로 기록된 항목만 확인하지 않는다."""
import hashlib
import json
from pathlib import Path
from model import D, HERE, GuardModel, VERSION

CODE_FILES = ("model.py", "probability.py", "insights.py", "monitor.py", "simulate.py", "runtime.py", "train.py", "predict.py", "recalibrate.py", "analyze.py",
              "audit.py", "verify.py", "contracts.py", "equivalence.py", "serve.py", "benchmark.py", "tools/clean_repro.sh", "web/app.js", "web/index.html", "web/style.css")
TRAIN_TABLES = ("metrics.csv", "rolling.csv", "cases_A.csv", "cases_B.csv", "incidents_A.csv", "incidents_B.csv")
PREDICTIONS = tuple(f"predictions_{kind}_{sid}.csv" for kind in ("normal", "abnormal") for sid in ("A", "B")) + ("test_predictions_A.csv", "test_predictions_B.csv")
ANALYSIS_TABLES = ("model_comparison_v2.csv", "robustness_v2.csv", "sensitivity_v2.csv", "ablation_v2.csv", "error_conditions_v2.csv",
                   "error_conditions_segments_v2.csv", "interaction_2x2_v2.csv", "records_first_alarm_v2.csv", "uncertainty_v2.csv", "workload_v2.csv",
                   "decision_table_v2.csv")
# 루브릭 사이클2 보강 표(verify 동결 대상)와 그림
INSIGHT_TABLES = ("probability_eval_v2.csv", "probability_reliability_v2.csv", "probability_conversion_v2.csv", "alert_levels_v2.csv",
                  "alert_budget_design_v2.csv", "queue_mixed_ranks_v2.csv", "queue_injection_ranks_v2.csv", "queue_key_selection_v2.csv",
                  "sensor_importance_v2.csv", "position_vibration_misses_v2.csv", "coupling_fit_v2.csv", "coupling_records_v2.csv",
                  "fp_events_v2.csv", "near_miss_v2.csv", "near_miss_corr_v2.csv", "error_conditions_stats_v2.csv",
                  "alert_levels_injection_v2.csv", "quality_windows_v2.csv", "label_free_alert_probability_v2.csv", "monitor_gain_v2.csv",
                  "expected_effect_v2.csv", "fp_intensity_v2.csv", "fn_intensity_v2.csv", "error_condition_summary_v2.csv", "incident_summary_v2.csv",
                  "unit_results_v2.csv", "probability_baselines_v2.csv")
INSIGHT_FILES = list(INSIGHT_TABLES) + ["fig_sensor_importance_v2.png", "fig_coupling_v2.png", "fig_false_alarm_cases_v2.png", "fig_probability_reliability_v2.png", "fig_position_vibration_v2.png"]
ANALYSIS_FILES = ANALYSIS_TABLES + INSIGHT_TABLES + ("analysis_summary.json", "model_comparison_v2.md", "fig_recall_by_position_v2.png",
                                    "fig_first_alarm_v2.png", "fig_missed_example_v2.png", "fig_sensor_importance_v2.png", "fig_coupling_v2.png",
                                    "fig_false_alarm_cases_v2.png", "fig_probability_reliability_v2.png", "fig_position_vibration_v2.png")
MODEL_ARTIFACTS = ("guard_A.json", "guard_B.json")
PROBABILITY_ARTIFACTS = ("probability_A.json", "probability_B.json")   # 경보와 무관한 이상 확률 층
ARTIFACTS = MODEL_ARTIFACTS + PROBABILITY_ARTIFACTS
# v1의 실행 중 manifest(타이밍·run_id가 매 실행마다 바뀜)는 분석 시점에 analyze.source_hashes()가 예측 파일 해시로 확인한다.
# 여기 넣으면 v1 패키지를 다시 실행할 때마다 v2 verify가 깨진다(패키지 간 결합).
SOURCES = ("press_submission/outputs/expected/manifest.json",
           "press_submission/outputs/model_comparison_all.csv", "press_submission/outputs/predictions_A.csv",
           "press_submission/outputs/predictions_B.csv", "analysis/press_advance/manifest.json",
           "analysis/press_advance/metrics.csv", "analysis/press_advance/run_experiment.py")
AUDIT_NAMES = ("실행 코드·선행 산출물이 manifest와 같음", "저장 모델이 manifest와 같음", "v1 의존 코드가 학습 당시와 같음",
               "입력 자료 해시가 학습 당시와 같음") + tuple(
    f"{sid} {name}" for sid in ("A", "B") for name in ("입력 묶음 1·7·128행과 전체 추론 동일", "독립 집계가 metrics.csv와 같음",
        "p값이 보정 순위 규칙과 같음", "구간당 알림은 경보 유무와 일치(정확성)", "이상 21구간 모두 탐지(성능 회귀)", "날짜 이동·라벨 변경에 불변"))


def read_json(path):
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict): raise ValueError(f"{path}: JSON 객체가 아님")
    return value


def check_files(root, recorded, required):
    bad=[]
    recorded=recorded if isinstance(recorded,dict) else {}
    for name in required:
        p=Path(root)/name
        if not p.is_file(): bad.append(f"{name}: 없음")
        elif name not in recorded: bad.append(f"{name}: 실행 해시 없음")
        elif D.sha256_file(p)!=recorded[name]: bad.append(f"{name}: 실행 후 변경")
    return bad


def training_fingerprint(manifest):
    parts={k:manifest.get(k) for k in ("version","input_hashes","code_hashes","artifacts","outputs","config")}
    return hashlib.sha256(json.dumps(parts,sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def run_fingerprint(manifest):
    parts=dict(training=training_fingerprint(manifest),analysis=manifest.get("analysis"))
    return hashlib.sha256(json.dumps(parts,sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def training_errors(manifest, out, artifacts, code_root=HERE):
    bad=[]
    if manifest.get("version")!=VERSION: bad.append("manifest version 불일치")
    if manifest.get("input_hashes")!=D.EXPECTED_SHA256: bad.append("고정 입력 자료 해시 불일치")
    if manifest.get("config",{}).get("rolling") is not True: bad.append("rolling 평가 미실행")
    bad+=check_files(code_root,manifest.get("code_hashes"),CODE_FILES)
    bad+=check_files(out,manifest.get("outputs"),TRAIN_TABLES+PREDICTIONS)
    bad+=check_files(artifacts,manifest.get("artifacts"),ARTIFACTS)
    for name in PROBABILITY_ARTIFACTS:
        try:
            from probability import ProbabilityCalibrator
            cal=ProbabilityCalibrator.load(Path(artifacts)/name)
            if cal.state.get("split")!=name.removeprefix("probability_").removesuffix(".json"): bad.append(f"{name}: 분할 불일치")
        except (OSError,ValueError,KeyError,TypeError) as exc: bad.append(f"{name}: {exc}")
    for name in MODEL_ARTIFACTS:
        try:
            model=GuardModel.load(Path(artifacts)/name)
            if model.state.get("input_hashes")!=manifest.get("input_hashes"): bad.append(f"{name}: 입력 해시 불일치")
            if model.state.get("split")!=name.removeprefix("guard_").removesuffix(".json"): bad.append(f"{name}: 분할 불일치")
        except (OSError,ValueError,KeyError,TypeError) as exc: bad.append(f"{name}: {exc}")
    return bad


def analysis_errors(manifest, out, source_root=HERE.parent):
    analysis=manifest.get("analysis",{})
    bad=check_files(out,analysis.get("outputs"),ANALYSIS_FILES)
    if analysis.get("training_fingerprint")!=training_fingerprint(manifest): bad.append("analysis: 다른 학습 실행의 결과")
    bad+=check_files(source_root,analysis.get("sources"),SOURCES)
    return bad


def audit_errors(audit,manifest):
    bad=[]
    checks=audit.get("checks",[])
    checks=checks if isinstance(checks,list) else []
    names=[c.get("name") for c in checks if isinstance(c,dict)]
    if len(names)!=len(AUDIT_NAMES) or set(names)!=set(AUDIT_NAMES): bad.append("audit: 필수 검사 누락·중복")
    if len(checks)!=len(names) or any(c.get("ok") is not True for c in checks if isinstance(c,dict)): bad.append("audit: 개별 검사 실패")
    if audit.get("all_ok") is not True: bad.append("audit: all_ok가 아님")
    if audit.get("run_fingerprint")!=run_fingerprint(manifest): bad.append("audit: 다른 코드·모델·산출물의 실행")
    if audit.get("version")!=manifest.get("version"): bad.append("audit: version 불일치")
    return bad


def execution_errors(manifest,out,artifacts,require_audit=True):
    bad=training_errors(manifest,out,artifacts)+analysis_errors(manifest,out)
    if require_audit:
        bad+=check_files(out,{"audit.json":manifest.get("audit_sha256")},("audit.json",))
        try: bad+=audit_errors(read_json(Path(out)/"audit.json"),manifest)
        except (OSError,ValueError,TypeError) as exc: bad.append(f"audit.json: {exc}")
    return bad
